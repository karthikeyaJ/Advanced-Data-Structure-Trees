#include "BTree.h"
#include "Interfaces04.h"
#include "BTreeNode.h"
#include <iostream>

void BTree::insert(int key, int num_keys)
{

	if (node == NULL)
	{
		node = new BTreeNode();
		range = num_keys;

		node->setKey(0, key);
		node->setKeySize(1);

	}
	else
	{
		/*for (int i = 0; i < node->getChildSize(); i++)
		{
			std::cout << "\nchild:" << i;
			for (int j = 0; j < node->getChild(i)->getKeySize(); j++)
			{
				std::cout << "key:" << node->getChild(i)->getKey(j) << ",";
			}
		}*/

		if (node->getKeySize() == num_keys)
		{
			BTreeNode *parent = new BTreeNode();
			parent->setChild(0, node);
			parent->setChildSize(parent->getChildSize() + 1);



			split(parent, 0);
			//int i = 0;

			//if (parent->getKey(i) < key)
			//	i++;

			BTreeNode* temp = new BTreeNode();
			temp = (BTreeNode*)parent->getChild(1);            //C[i]->insertNonFull(k);

			insertInNonFull(parent, key, num_keys);
			// Change root
			node = parent;

			/*for (int p = 0; p < node->getKeySize(); p++)
				std::cout << node->getKey(p), std::cout << "";
			std::cout << std::endl;

			for (int p = 0; p < node->getChild(0)->getKeySize(); p++)
				std::cout << node->getChild(0)->getKey(p), std::cout << "";
			std::cout << std::endl;


			for (int p = 0; p < node->getChild(1)->getKeySize(); p++)
				std::cout << node->getChild(1)->getKey(p), std::cout << "";
			std::cout << std::endl;*/

		}

		else
		{
			insertInNonFull(node, key, num_keys);
		}

	}

}
void BTree::insertInNonFull(BTreeNode* node,int key, int num_keys)
{
	int i = node->getKeySize();

	if (node->isLeaf())
	{
		while (i >= 1 && (key < node->getKey(i-1)))
		{
			i = i - 1;
			node->setKey(i + 1, node->getKey(i));
		}
		node->setKey(i, key);
		node->setKeySize(node->getKeySize() + 1);
	}
	else
	{
	
		while (i >= 1 && key<node->getKey(i-1))
		{
			i=i-1;
		}

		//i = i + 1;
		if (node->getChild(i)->getKeySize() == num_keys)
		{
		
			split(node, i);
			if (key > node->getKey(i))
				i = i + 1;
		}

		
			insertInNonFull((BTreeNode*)node->getChild(i),key,num_keys);

	}
}



void BTree::split(BTreeNode* x, int i)
{
	BTreeNode *y = (BTreeNode*)x->getChild(i);
	BTreeNode *z = new BTreeNode();
	int t = (1 + range) / 2;
	int n = t - 1;

	for (int j = 0; j < t - 1; j++)
	{
		z->setKey(j, y->getKey(j + t));
		//y->setKey(j + t, NULL);
		z->setKeySize(z->getKeySize() + 1);
	}

	if (y->isLeaf() == false)
	{
		y->setChildSize(y->getChildSize() - 3);
	
		for (int j = 0; j < t; j++)
		{
			z->setChild(j, y->getChild(j + t));
			z->setChildSize(z->getChildSize()+1);
		}
	}

	y->setKeySize(y->getKeySize() - n);

	for (int j = x->getKeySize(); j >= i+1; j--)
	{
		x->setChild(j + 1, x->getChild(j));
	}

	x->setChild(i + 1, z);

	for (int j = x->getKeySize() - 1; j >= i; j--)
		x->setKey(j + 1, x->getKey(j));


	x->setKey(i, y->getKey(t - 1));
	x->setKeySize(x->getKeySize() + 1);
	y->setKeySize(y->getKeySize() - 1);
	x->setChildSize(x->getChildSize() + 1);
}

void BTree::remove(int key, int num_keys)
{

}

int BTree::kthMin(int k)
{

	IBTreeNode* p = getRoot();


	for (int i = 0; i < p->getKeySize(); i++)
	{

		//std::cout << p->getKey(i) << std::endl;
		if (k == (i))
			return p->getKey(i);


	}


	//}
	//if (k < p->getKey(i))
	//{
	//	int result = kthMinimum(curr->getLeft(), k);
	//	return result;
	//}
	//if (k>count_left)
	//{
	//	int result = kthMinimum(curr->getRight(), k - count_left - 1);
	//	return result;
	//}
	//if (k == count_left)
	//{
	//	return curr->getKey();
	//}


	//return 23;
}

IBTreeNode *BTree::getRoot()
{
	return node;
}

