#include "Interfaces04.h"
#include "AVLTree.h"
//#include "AVLTreeNode.h"
#include <iostream>     // std::cout

AVLTree::AVLTree() { }
AVLTree ::~AVLTree() { }
void AVLTree::insert(int key)
{
	IAVLTreeNode* t = new AVLTreeNode();
	t->setKey(key);
	t->setLeft(NULL);
	t->setRight(NULL);
	if (root == NULL)
		root = t;

	else
	{
		root=add(root, key);
	}
}

int AVLTree::balance(IAVLTreeNode* root)
{
	int left_height = calcHeight(root->getLeft());
	int right_height = calcHeight(root->getRight());
	int diff = left_height - right_height;
	return diff;
}


IAVLTreeNode* AVLTree::add(IAVLTreeNode * dup_root, int key)
{
					IAVLTreeNode* curr = dup_root;

					if (curr == NULL)
					{

						curr = new AVLTreeNode();
						curr->setKey(key);
						curr->setLeft(NULL);
						curr->setRight(NULL);
						return curr;
					}

					if (key < dup_root->getKey())
					{
						dup_root->setLeft(add(curr->getLeft(), key));

						IAVLTreeNode* new_root = new AVLTreeNode();
						IAVLTreeNode* parent, *temp;
						new_root = dup_root;


						int left_height = calcHeight(dup_root->getLeft());
						int right_height = calcHeight(dup_root->getRight());
						int diff = left_height - right_height;
						if (diff == -1 || diff==0 || diff==1)
							return dup_root;
						parent = new_root;
						temp = parent;
						while (diff == 2)
						{
							temp = parent;
							parent = new_root;
							new_root = new_root->getLeft();
							diff = balance(new_root);
												if (diff == 1)
												{
													if (dup_root == parent)
													{
														if (root == parent)
														{
															parent = rightRotation(parent);
															root = parent;

														}
														else
															parent = rightRotation(parent);
														return parent;

													}
													else
													{
														parent = rightRotation(parent);
														temp->setLeft(parent);
													}


												}

												else if (diff == -1)
												{
													new_root = leftRotation(new_root);
													parent->setLeft(new_root);
													parent = rightRotation(parent);
													return parent;


												}

						}
					}

					if (key>dup_root->getKey())
					{
						dup_root->setRight(add(curr->getRight(), key));

						/////////////
						IAVLTreeNode* new_root = new AVLTreeNode();
						IAVLTreeNode* parent, *temp;
						new_root = dup_root;


						int left_height = calcHeight(dup_root->getLeft());
						int right_height = calcHeight(dup_root->getRight());
						int diff = left_height - right_height;
						if (diff == -1 || diff==0 || diff==1)
							return dup_root;
						parent = new_root;
						temp = parent;
						while (diff == -2)
						{
							temp = parent;
							parent = new_root;


							new_root = new_root->getRight();
							diff = balance(new_root);

							if (diff == -1)
							{
								//root = leftRotation(parent);

								if (dup_root == parent)
								{
									if (root == parent)
									{
										parent = leftRotation(parent);
										root = parent;

									}
									else
									parent = leftRotation(parent);
									return parent;

								}
								else
								{
									parent = leftRotation(parent);
									temp->setRight(parent);
								}


							}

							else if (diff == 1)
							{
								new_root = rightRotation(new_root);
								parent->setRight(new_root);
								parent = leftRotation(parent);
								return parent;


							}

						}
						////////////



					}
					return root;
}

int AVLTree::calcHeight(IAVLTreeNode * curr)
{
	if (curr == NULL)
	{
		return 0;
	}

	int left_height = calcHeight(curr->getLeft());
	int right_height = calcHeight(curr->getRight());

	if (left_height > right_height)
	{
		return left_height + 1;
	}

	else {
		return right_height + 1;
	}
}

IAVLTreeNode* AVLTree::rightRotation(IAVLTreeNode * Q)
{
	IAVLTreeNode *p = Q->getLeft();
	Q->setLeft(p->getRight());
	p->setRight(Q);

	return p;

}
IAVLTreeNode* AVLTree::leftRotation(IAVLTreeNode * p)
{
	IAVLTreeNode *Q = p->getRight();
	p->setRight(Q->getLeft());
	Q->setLeft(p);

	return Q;

}




void AVLTree::remove(int key)
{

	 deleted(NULL,root, key);

}



void AVLTree::deleted(IAVLTreeNode* parent, IAVLTreeNode* dup_root, int key)
{
	if (parent == NULL)
		parent = dup_root;
	else
		parent = parent;
	IAVLTreeNode* parent1=NULL, *child=NULL;
	parent1 = dup_root;
	
	if (key == dup_root->getKey())
	{
		int left_height = calcHeight(dup_root->getLeft());
		int right_height = calcHeight(dup_root->getRight());

		if (left_height == 0 && right_height == 0)
		{
			if (parent1->getLeft() == dup_root)
			{
			parent1->setLeft(NULL);
			}

			else if (parent1->getRight() == dup_root)
			{
				parent1->setRight(NULL);
			}
		
		}

		else if ((left_height == 0 && right_height != 0) )
		{
			if (parent1->getLeft() == dup_root)
			{
				child = dup_root->getRight();
				parent1->setLeft(child);
			}
		
		}
		
		else if ((left_height != 0 && right_height == 0))
		{
			if (parent1->getRight() == dup_root)
			{
				child = dup_root->getLeft();
				parent1->setRight(child);
			}
		
		}
		else if (left_height != 0 && right_height != 0)
		{
		
			while (dup_root->getRight() != NULL)
			{
				dup_root = dup_root->getRight();
				child = dup_root;
			}
			dup_root->setKey(child->getLeft()->getKey());
			child->setLeft(NULL);
		
		}



	}

	if (key<dup_root->getKey())
		deleted(parent,dup_root->getLeft(), key);

	if (key>dup_root->getKey())
		deleted(parent,dup_root->getRight(), key);


	


}

int AVLTree::kthMin(int k)
{

	int i = 0;
	return i;
}

IAVLTreeNode *AVLTree::getRoot()
{
	return root;

}